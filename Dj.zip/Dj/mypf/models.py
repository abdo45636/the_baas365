from django.db import models

# Create your models here.

# Creating Contact Model
class Contact(models.Model):
    email = models.EmailField()
    subject = models.CharField(max_length=196)
    message = models.TextField()
   # timestamp = models.DataTimeField(auto_now_add=True,auto_now=False)
   # updated = models.DataTimeField(auto_now_add=False, auto_now=True)

    def __unicode__(self):
        return self.email